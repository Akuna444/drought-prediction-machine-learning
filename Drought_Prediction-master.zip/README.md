# Drought_Prediction
From the monthly rainfall data from 1901 - 1970 forecasted future rainfall using Time series models.
Converted the rainfall data into SPI and SPAI series and classify the drought years and prepared a detailed report.
